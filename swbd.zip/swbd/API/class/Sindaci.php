<?php
	
	require_once __DIR__ . '/Rest.php';

	class Sindaci extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Sindaci"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertSindaco($rowSindaco) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(nome, cognome, CF, data_nascita) 
					VALUES (?, ?, ?, ?)";
			
			$params = [
				$rowSindaco["nome"],
				$rowSindaco["cognome"],
				$rowSindaco["CF"],
				$rowSindaco["data_nascita"]
			];
			
			$types = "ssss"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateSindaco($rowSindaco){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					nome = ?, 
					cognome = ?, 
					CF = ?, 
					data_nascita = ? 
				WHERE ID = ?";
			
			$params = [
				$rowSindaco["nome"],
				$rowSindaco["cognome"],
				$rowSindaco["CF"],
				$rowSindaco["data_nascita"],
				$rowSindaco["ID_sindaco"]
			];

			$types = "ssssi"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}


?>