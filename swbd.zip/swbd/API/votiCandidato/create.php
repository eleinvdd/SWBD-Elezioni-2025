<?php
	require_once __DIR__ . '/../class/VotiCandidato.php';

	header('Content-Type: application/json');

	$api = new VotiCandidato();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowVotoCandidato["ID_voto"] = $input['ID_voto'];
	$rowVotoCandidato["ID_candidato"] = $input['ID_candidato'];

	$response = $api->insertVotoCandidato($rowVotoCandidato);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>