<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Candidati</title>
        <!-- <link rel="stylesheet" href="../../CSS/style.css"> !-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    </head>

    <header>
    </header>
    <body>

        <!-- NAVIGATION BAR -------------------------------------------------------------------------------------------------------------->
        <script src="navbarAdmin.js"></script>

        <!--  ---------------------------------------------------------------------------------------------------------------------------->
       
        <!-- TUTTI I CANDIDATI---------------------------------------------------------------------------------------------------------------------------->
        <section class="section" id="candidati-container">
            <!-- I candidati verranno caricate qui dinamicamente -->
        </section>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <!-- JAVASCRIPT ------------------------------------------------------------------------------------------------------------------>
        <script src="../../JAVASCRIPT/index.js"></script>
        <script src="../../JAVASCRIPT/components/show/showCandidati.js"></script>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>