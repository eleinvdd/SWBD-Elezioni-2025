<?php
	
    require_once __DIR__ . '/../API/class/Cittadini.php';
	require_once __DIR__ . '/../API/class/Voti.php';
    require_once __DIR__ . '/../API/class/VotiLista.php';
    require_once __DIR__ . '/../API/class/VotiCandidato.php';


    header('Content-Type: application/json');

    $input = json_decode(file_get_contents("php://input"), true);
	
    $ID_seggio = $input['ID_seggio'];
    $ID_sindaco = $input['ID_sindaco'];
    $ID_lista = $input['ID_lista'];
    $ID_candidati = $input['ID_candidati']; //NB è un array
    $CF = $input['CF'];

    if (empty($ID_seggio) || empty($ID_sindaco)) {
        echo json_encode(['successo' => 0, 'messaggio' => 'error: ID_seggio e ID_sindaco mancanti']);
        exit;
    }

    try {

        //VOTAZIONE SEMPLICE ---------------------------------------------------------------------------------
        $apiVoti = new Voti();
        $rowVoto = ['ID_seggio' => $ID_seggio, 'ID_sindaco' => $ID_sindaco];
        $response = $apiVoti->insertVoto($rowVoto);
        $ID_voto = $response['insert_id'];

        $apiCittadini = new Cittadini();
        $apiCittadini->votazione($ID_voto, $CF);

        //VOTAZIONE (anche) ALLA LISTA --------------------------------------------------------------------
        if (!empty($ID_lista)) {
            $apiVotiLista = new VotiLista();
            $rowVotoLista = ['ID_voto' => $ID_voto, 'ID_lista' => $ID_lista];
            $apiVotiLista->insertVotoLista($rowVotoLista);
        }

        //VOTAZIONE (anche) AI CANDIDATI --------------------------------------------------------------
        if (!empty($ID_candidati) && is_array($ID_candidati)) {
            $apiVotiCandidato = new VotiCandidato();
            foreach ($ID_candidati as $ID_candidato) {
                $rowVotoCandidato = ['ID_voto' => $ID_voto, 'ID_candidato' => $ID_candidato];
                $apiVotiCandidato->insertVotoCandidato($rowVotoCandidato);
            }
        }

        session_start();
        if($_SESSION['userType'] == "Cittadino"){
                $_SESSION['voto'] = true;
        }

        echo json_encode(["successo" => 1]);

    } catch (Exception $e) {
        echo json_encode(['successo' => 0, 'messaggio' => $e->getMessage()]);
    }
?>