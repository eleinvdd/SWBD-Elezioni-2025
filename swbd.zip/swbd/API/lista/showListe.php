<?php
	
	require_once __DIR__ . '/../class/Liste.php';

    $api = new Liste();
    $response = $api->getRows(null);

    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);

?>