<?php

    function auth($userType){


        header('Content-Type: application/json');

        $input = json_decode(file_get_contents("php://input"), true);
        
        $ID_utente = $input['ID_utente'];
        $email = $input['email'];
        $userType = $input['userType'];
        $CF = $input['CF']; //NB è un array

        session_start();
        if (!isset($_SESSION['email']) && !isset($_SESSION['userType'] && $_SESSION['userType'] =! $userType)) {
            header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/home.php");
            exit();
        }
    }
    
?>