document.write(`
<script src="../JAVASCRIPT/burger.js"></script>
`);