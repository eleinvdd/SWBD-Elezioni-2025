<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="../CSS/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    </head>

    <header>
        <!--
        <a href="../HTML/home.php" class="title has-text-centered"><h1>HOME</h1></a>
        a<h1 class="has-text-weight-bold has-text-centered">PAGINA DI LOGIN</h1>
       -->
    </header>
    <body>


        <!-- NAVIGATION BAR -------------------------------------------------------------------------------------------------------------->
        <script src="../JAVASCRIPT/components/navbar.js"></script>

        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <!-- BREADCRUMBS ----------------------------------------------------------------------------------------------------------------->
        <!--
        <div class="section py-2 px-2"></div>
        <nav class="breadcrumb has-succeeds-separator" aria-label="breadcrumbs">
            <ul class="container is-size-6">
                <li class="has-text-grey"><a href="../HTML/home.php">Home</a></li>
                <li class="is-active"><a href="../HTML/login.php" aria-current="page">Login</a></li>
            </ul>
        </nav>
        -->
        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <section class="section">
            <div class="tabella-login">
                <form action="../PHP/login.php" method="post">
                    <tr>
                        <th colspan="2" class="is-size-1 title">LOGIN</th>
                    </tr>

                    <hr class="my-5"></hr>

                    <tr>
                        <td colspan="2">
                            <h1>Email</h1>
                            <input type="email" name="email" placeholder="email">
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <h1>Password</h1>
                            <input type="password" name="password" placeholder="password">
                        </td>
                    </tr>

                    <hr class="my-5"></hr>

                    <tr>
                        <td colspan="1">
                            <input type="submit" name="invio" value="Login">
                        </td>
                        <td colspan="1">
                            <input type="reset" name="cancella" value="Annulla">
                        </td>
                    </tr>
                </form>
            </div>
        </section>
        

        <!-- JAVASCRIPT ------------------------------------------------------------------------------------------------------------------>
        <script src="../JAVASCRIPT/index.js"></script>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>