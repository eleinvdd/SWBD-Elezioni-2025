document.write(`
<nav class="navbar has-shadow">
            <div class="logo">
                <a class="navbar-item" href="../../HTML/home.php">
                    <img src="../../media/logo_bianco.png" alt="logoVanvitelliBianco" style="max-height: 70px;" class="py-2 px-2">
                </a>
            </div>

            <a class="navbar-burger" id="burger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </a>

            <div class="navbar-menu" id="nav-links">
                <div class="navbar-start">
                    <a class="navbar-item" href="cittadini.php">Cittadini</a>
                    <a class="navbar-item" href="addetti.php">Addetti</a>
                    <a class="navbar-item" href="candidati.php">Candidati</a>
                    <a class="navbar-item" href="sindaci.php">Sindaci</a>
                    <a class="navbar-item" href="liste.php">Liste</a>
                </div>
                <div class="navbar-end">
                    <a class="navbar-item" href="../registrazione.php">Registrazione</a>
                    <a class="navbar-item" href="../login.php">Login</a>
                </div>
            </div>
        </nav>
`);