<?php
	require_once __DIR__ . '/../class/Utenti.php';

	header('Content-Type: application/json');

	$api = new Utenti();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_utente = $input['ID_utente'];

	$response = $api->getRows($ID_utente);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>