<?php
    //header("Access-Control-Allow-Origin: *");
    function checkEsecuzioneQuery($result){
        if(!$result)
            exit("Errore: impossibile eseguire la query. " . mysqli_error($conn));
        return $result;
    }

    
?>