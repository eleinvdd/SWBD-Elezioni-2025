
// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Fetch dei dati
        const fetchSindaci = await fetch('http://localhost/swbd/API/sindaco/showSindaci.php');
        const sindaci = await fetchSindaci.json();
        
        const fetchListe = await fetch('http://localhost/swbd/API/lista/showListe.php');
        const liste = await fetchListe.json();

        const fetchCandidati = await fetch('http://localhost/swbd/API/candidato/showCandidati.php');
        const candidati = await fetchCandidati.json();
        
        if(sindaci.successo === 1 && liste.successo === 1 && candidati.successo === 1){
            renderListePerSindaco(sindaci.data, liste.data, candidati.data);
        }
        else{
            if(sindaci.successo === 0) {
                console.error('Errore:', sindaci.messaggio);
                showError();}
            else if (liste.successo === 0){
                console.error('Errore:', liste.messaggio);
                showError();
            }
            else if (candidati.successo === 0){
                console.error('Errore:', candidati.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

async function renderListePerSindaco(sindaci, liste, candidati) {

    console.log("Risposta sindaci:", sindaci);
    console.log("Risposta liste:", liste);
    console.log("Risposta candidati:", candidati);

    const container = document.getElementById('liste-container');
    container.innerHTML = ''; // Pulisce prima

    sindaci.forEach(sindaco => {
        // Seleziona le liste legate a questo sindaco
        const listeDelSindaco = liste.filter(lista => lista.ID_sindaco == sindaco.ID);

        // Crea blocco sindaco + relative liste
        let sindacoHTML = `
        <div class="box">
            <h2 class="title is-2">Sindaco: ${sindaco.nome} ${sindaco.cognome}</h2>
            <hr class="my-5"></hr>
        `;

        listeDelSindaco.forEach(lista => {
            // Filtra i candidati
            const candidatiLista = candidati.filter(candidato => candidato.ID_lista == lista.ID);
            
            let candidatiHTML = '';
            candidatiLista.forEach(candidato => {
                candidatiHTML += `
                    (${candidato.numCandidato}: ${candidato.ruoloCandidato}) ${candidato.nome} ${candidato.cognome}<br>
                `;
            });

            sindacoHTML += `
            <div class="container">
                <div class="columns">
                    <div class="column is-size-3" id="liste-column">
                        <h1 class="is-size-4 title lista">${lista.titolo}</h1>
                        <p class="is-size-6">${lista.descrizione}</p>
                        <br>  
                        <p class="is-size-6 subtitle">${candidatiHTML}</p>
                        <hr class="my-5"></hr>
                    </div>
                </div>
            </div>
            `;
        });

        

        sindacoHTML += '</div><hr>';
        container.insertAdjacentHTML('beforeend', sindacoHTML);
    });
}

function showError() {
    const container = document.getElementById('liste-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento delle liste. Riprova più tardi.
        </div>
    `;
}
/*
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('http://localhost/swbd/API/lista/showListe.php');
        const result = await response.json();
        
        if (result.successo === 1) {
            renderListe(result.data);
        } else {
            console.error('Errore:', result.messaggio);
            showError();
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

function renderListe(sindaci, liste) {
    const container = document.getElementById('liste-container');
    
    liste.forEach(lista => {
        const listHTML = `
        <div class="container">
            <div class="columns">
                <div class="column is-size-3" id="liste-column">
                    <h1 class="is-size-1 title lista">${lista.titolo}</h1>
                    <h2 class="is-size-3 subtitle sindaco">Sindaco: ${lista.ID_sindaco}</h2>
                    <p class="is-size-6">${lista.descrizione}</p>
                </div>
                <section class="section" id="candidati-container">
                    <!-- I candidati -->
                </section>

            </div>
        </div>
        <hr class="my-5">
        `;
        
        container.insertAdjacentHTML('beforeend', listHTML);
    });
}*/
