<?php
	require_once __DIR__ . '/../class/Candidati.php';

	header('Content-Type: application/json');

	$api = new Candidati();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_candidato = $input['ID_candidato'];
	$response = $api->getRows($ID_candidato);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>