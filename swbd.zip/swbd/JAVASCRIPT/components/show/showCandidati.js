// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Fetch dei dati
        const fetchSindaci = await fetch('http://localhost/swbd/API/sindaco/showSindaci.php');
        const sindaci = await fetchSindaci.json();
        
        const fetchListe = await fetch('http://localhost/swbd/API/lista/showListe.php');
        const liste = await fetchListe.json();

        const fetchCandidati = await fetch('http://localhost/swbd/API/candidato/showCandidati.php');
        const candidati = await fetchCandidati.json();
        
        if(sindaci.successo === 1 && liste.successo === 1 && candidati.successo === 1){
            renderCandidatiPerSindaco(sindaci.data, liste.data, candidati.data);
        }
        else{
            if(sindaci.successo === 0) {
                console.error('Errore:', sindaci.messaggio);
                showError();}
            else if (liste.successo === 0){
                console.error('Errore:', liste.messaggio);
                showError();
            }
            else if (candidati.successo === 0){
                console.error('Errore:', candidati.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

async function renderCandidatiPerSindaco(sindaci, liste, candidati) {
    console.log("Risposta sindaci:", sindaci);
    console.log("Risposta liste:", liste);
    console.log("Risposta candidati:", candidati);

    const container = document.getElementById('candidati-container');
    container.innerHTML = ''; // Pulisce prima
    
    // Creiamo una mappa per trovare rapidamente una lista dato il suo ID
    const mappaListe = {};
    liste.forEach(lista => {
        mappaListe[lista.ID] = lista;
    });

    // Creiamo una mappa per trovare rapidamente un sindaco dato il suo ID
    const mappaSindaci = {};
    sindaci.forEach(sindaco => {
        mappaSindaci[sindaco.ID] = sindaco;
    });

    // Ordiniamo i candidati per numero di preferenze (decrescente)
    candidati.sort((a, b) => b.numPreferenze - a.numPreferenze);

    // Creiamo il contenuto HTML per ogni candidato
    candidati.forEach(candidato => {
        const lista = mappaListe[candidato.ID_lista];
        const sindaco = mappaSindaci[lista.ID_sindaco];
        
        const dataNascita = new Date(candidato.data_nascita);
        const dataFormattata = dataNascita.toLocaleDateString('it-IT');
        
        //CALCOLO ETA' --------------------------------------------------------------------------------
        const oggi = new Date();
        let eta = oggi.getFullYear() - dataNascita.getFullYear();
        const mese = oggi.getMonth() - dataNascita.getMonth();
        if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
            eta--;
        }

        const candidatoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${candidato.nome} ${candidato.cognome}</h2>
                    <h3 class="subtitle is-5">${candidato.ruoloCandidato}</h3>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${candidato.CF}</p>

                        <p><strong class="is-size-5">Sindaco di riferimento:</strong> ${sindaco.nome} ${sindaco.cognome}</p>
                        <p><strong class="is-size-5">Lista:</strong> ${lista.titolo}</p>              
                        <p><strong class="is-size-5">Numero candidato:</strong> ${candidato.numCandidato}</p>

                        <p><strong class="is-size-5">Preferenze:</strong> ${candidato.numPreferenze}</p>
                    </div>
                </div>
            </div>
        </div>
        `;

        container.insertAdjacentHTML('beforeend', candidatoHTML);
    });
}

function showError() {
    const container = document.getElementById('liste-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento dei candidati. Riprova più tardi.
        </div>
    `;
}