// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        
        //Fetch della sessione
        const fetchSessione = await fetch('http://localhost/swbd/PHP/config/userSession.php');
        const sessione = await fetchSessione.json();

        
        if(sessione.successo === 1){
            //generaTabelle(sindaci, liste, candidati, sessione);
        }
        else{
            if (sessione.successo === 0){
                console.error('Errore:', sessione.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

//devo prima fare la pagina profilo dell'utente con EVENTLISTENER SUL SEGGIO



const esitoVoto = {
                    ID_sindaco: parseInt(sindaco.ID),
                    
                    //id di testing, devo prenderlo dalla sessione
                    ID_seggio: 1, //sessione.ID_seggio
                    //id di testing, devo prenderlo dalla sessione
                    CF: sessione.CF,

                    ID_lista: listaId,
                    ID_candidati: candidatiSelezionati
                };



async function updateSeggio(){
    try{
        const fetchVotazione = await fetch('http://localhost/swbd/PHP/votazione.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(esitoVoto)
        });
        

        const votazione = await fetchVotazione.json();
        
        if (votazione.successo === 1) {
            alert("Voto registrato con successo!");
            location.reload();
        } else {
            alert("Errore durante la votazione: " + (votazione.message || ""));
        }
            
    } catch (error) {
        //console.log("la response:", votazione.successo);
        alert("Errore di connessione: " + error.message);
    }
}