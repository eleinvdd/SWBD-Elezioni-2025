-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Utenti (
    
  	ID 			INT AUTO_INCREMENT PRIMARY KEY,
    
  	email 	VARCHAR(50)	NOT NULL UNIQUE,
    pass 		VARCHAR(255)	NOT NULL,
  	CF			VARCHAR(16) NOT NULL UNIQUE,
  
  	userType ENUM('Cittadino', 'Addetto', 'Candidato', 'Sindaco', 'Admin') NOT NULL DEFAULT 'Cittadino'
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Sindaci (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    
  	nome 							VARCHAR(50)	NOT NULL,
    cognome 					VARCHAR(50)	NOT NULL,
    data_nascita 			DATE				NOT NULL,
    CF 								VARCHAR(16) NOT NULL UNIQUE,
  	
  	numPreferenze 		INT 				NOT NULL DEFAULT 0,
  
    ID_utente 				INT					UNIQUE,
  
  	FOREIGN KEY (ID_utente) REFERENCES Utenti(ID)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Liste (
    ID INT AUTO_INCREMENT PRIMARY KEY,
  	
  	titolo 				VARCHAR(50) NOT NULL,
  	numPreferenze INT 				NOT NULL DEFAULT 0,
  	ID_sindaco 		INT					NOT NULL,
  	descrizione		TEXT
  	
  	UNIQUE (titolo),
  	FOREIGN KEY (ID_sindaco) REFERENCES Sindaci(ID)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Candidati (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    
  	nome 							VARCHAR(50)	NOT NULL,
    cognome 					VARCHAR(50)	NOT NULL,
    data_nascita 			DATE				NOT NULL,
    CF 								VARCHAR(16) NOT NULL UNIQUE,
    
  	ruoloCandidato 		VARCHAR(50) NOT NULL DEFAULT 'Candidato Semplice',

  	ID_lista 					INT 				NOT NULL,
    numCandidato 			INT 				NOT NULL,
    
  	numPreferenze 		INT					NOT NULL	DEFAULT 0,
		
    ID_utente 				INT					UNIQUE,
  	
    UNIQUE (ID_lista, numCandidato),
    FOREIGN KEY (ID_lista) REFERENCES Liste(ID),
  	FOREIGN KEY (ID_utente) REFERENCES Utenti(ID),
  
  	CONSTRAINT CHECK_ruoloCandidato CHECK (ruoloCandidato = 'Assessore' OR ruoloCandidato = 'Consigliere' OR ruoloCandidato = 'Candidato Semplice')
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Seggi (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    
  	comune 			VARCHAR(50)		NOT NULL,
    via 	 			VARCHAR(100)	NOT NULL,
    civico 			SMALLINT 			NOT NULL,
    numAbitanti INT 					NOT NULL DEFAULT 0,
  
  	UNIQUE(comune, via, civico)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Addetti (
    
  	ID INT AUTO_INCREMENT PRIMARY KEY,
    
  	nome 					VARCHAR(50)	NOT NULL,
    cognome 			VARCHAR(50)	NOT NULL,
    data_nascita	DATE				NOT NULL,
    CF 						VARCHAR(16)	NOT NULL UNIQUE,
  	
    ruolo 				VARCHAR(50) NOT NULL DEFAULT 'Assistente',
  /*ruolo					ENUM('Supervisore', 'Assistente', 'Segretario') DEFAULT 'Assistente',*/
  	ID_seggio 		INT 				NOT NULL,
    ID_utente 		INT					UNIQUE,
  
  	FOREIGN KEY (ID_seggio) REFERENCES Seggi(ID),
  	FOREIGN KEY (ID_utente) REFERENCES Utenti(ID),
  	
  	CONSTRAINT CHECK_ruolo CHECK (ruolo = 'Supervisore' OR ruolo = 'Assistente' OR ruolo = 'Segretario')
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Voti (
    ID INT AUTO_INCREMENT PRIMARY KEY,
  	
  	ID_seggio  	INT NOT NULL,
  	ID_sindaco  INT NOT NULL,
  	
  	FOREIGN KEY (ID_seggio) REFERENCES Seggi(ID),
  	FOREIGN KEY (ID_sindaco) REFERENCES Sindaci(ID)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VotiLista (
    
  	ID_voto 		 INT NOT NULL,
    ID_lista		 INT NOT NULL,
    
    PRIMARY KEY (ID_voto),
    
    FOREIGN KEY (ID_voto) REFERENCES Voti(ID),
    FOREIGN KEY (ID_lista) REFERENCES Liste(ID)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VotiCandidato (
    
  	ID_voto 		 INT NOT NULL,
    ID_candidato INT NOT NULL,
    
    PRIMARY KEY (ID_voto, ID_candidato),
    
    FOREIGN KEY (ID_voto) REFERENCES Voti(ID),
    FOREIGN KEY (ID_candidato) REFERENCES Candidati(ID)
);
-- --------------------------------------------------------------------

-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Cittadini (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    
  	nome 							VARCHAR(50)	NOT NULL,
    cognome 					VARCHAR(50)	NOT NULL,
    data_nascita 			DATE				NOT NULL,
    CF 								VARCHAR(16) NOT NULL UNIQUE,
  	
  	ID_voto				 		INT,
  	ID_utente 				INT					UNIQUE,
  
  	FOREIGN KEY (ID_voto) REFERENCES Voti(ID),
  	FOREIGN KEY (ID_utente) REFERENCES Utenti(ID)
);

-- --------------------------------------------------------------------















