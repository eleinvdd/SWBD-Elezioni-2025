<?php
	
	require_once __DIR__ . '/Rest.php';

	class Cittadini extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Cittadini"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertCittadino($rowCittadino) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(nome, cognome, CF, data_nascita) 
					VALUES (?, ?, ?, ?)";
			
			$params = [
				$rowCittadino["nome"],
				$rowCittadino["cognome"],
				$rowCittadino["CF"],
				$rowCittadino["data_nascita"]
			];
			
			$types = "ssss"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateCittadino($rowCittadino){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					nome = ?, 
					cognome = ?, 
					CF = ?, 
					data_nascita = ? 
				WHERE ID = ?";
			
			$params = [
				$rowCittadino["nome"],
				$rowCittadino["cognome"],
				$rowCittadino["CF"],
				$rowCittadino["data_nascita"],
				$rowCittadino["ID_cittadino"]
			];

			$types = "ssssi"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------
		public function votazione($ID_voto, $CF){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					ID_voto = ? 
				WHERE CF = ?";
			
			$params = [
				$ID_voto,
				$CF
			];

			$types = "is"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		
	}

    //funzione per associare il voto al cittadino


?>