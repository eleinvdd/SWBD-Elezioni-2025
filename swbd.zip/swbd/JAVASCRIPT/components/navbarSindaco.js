document.write(`
<nav class="navbar has-shadow">
    <div class="logo">
        <a class="navbar-item" href="../HTML/homeSindaco.php">
            <img src="../media/logo_bianco.png" alt="logoVanvitelliBianco" style="max-height: 70px;" class="py-2 px-2">
        </a>
    </div>

    <a class="navbar-burger" id="burger">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </a>

    <div class="navbar-menu" id="nav-links">
        <div class="navbar-end">
            <a class="navbar-item" href="../PHP/logout.php">Logout</a>
        </div>
    </div>
</nav>
`);