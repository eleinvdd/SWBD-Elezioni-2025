<?php
	require_once __DIR__ . '/../class/VotiCandidato.php';

	header('Content-Type: application/json');

	$api = new VotiCandidato();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_voto = $input['ID_voto'];

	$response = $api->deleteFromId($ID_voto);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>