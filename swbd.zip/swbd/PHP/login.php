<?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/swbd/PHP/index.php');

    //le variabili di sessione vanno aggiunte qui?

    $email = $_POST['email'];
    $email = $conn->real_escape_string($email);
    $email = stripslashes($email);
    $email = strtolower($email);
    
    $password = $_POST['password'];
    $password = $conn->real_escape_string($password);

    //dato che password_hash() genera un hash diverso ogni volta,
    //devo ricavare quello presente nel database e usare password_verify()

    $stmt = $conn->prepare("SELECT * FROM utenti WHERE email = ?");
    $stmt->bind_param("s", $email);
    
    if(!$stmt->execute())
        die("Errore nell'esecuzione: " . $stmt->error);
    
    $result = $stmt->get_result();
    $stmt->close();

    //SE TROVA L'EMAIL VERIFICA LA PASSWORD
    if($result->num_rows == 1){
        $row_utente = $result->fetch_assoc();

        if(password_verify($password, $row_utente['pass'])){

            session_start();
            $_SESSION['ID_user'] = $row_utente['ID'];
            $_SESSION['email'] = $row_utente['email'];
            $_SESSION['userType'] = $row_utente['userType'];
            $_SESSION['CF'] = $row_utente['CF'];

            /*
            if($_SESSION['userType'] == "Cittadino"){
                $_SESSION['voto'] = false;
                $_SESSION['ID_seggio'] = 1;
            }
            */

            if($_SESSION['userType'] == "Admin"){
                header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/admin.php");
                exit();
            }
            else{
                header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/home". $_SESSION['userType'] .".php");
                exit();
            }

        }
        else{
            header('Content-Type: application/json');
            echo json_encode(["error" => "Password errata"]);
        }

    }else{
        echo '<script>alert("Utente errato");</script>';
    }

    

?>