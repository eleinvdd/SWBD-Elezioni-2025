<?php
    session_start();
    require_once($_SERVER['DOCUMENT_ROOT'] . '/swbd/PHP/index.php');

    $sessione = ["successo" => 0, "messaggio" => "Utente non autenticato"];

    if (isset($_SESSION['ID_user'])) {
        $sessione = [
            "successo" => 1,
            "ID_user" => $_SESSION['ID_user'],
            "email" => $_SESSION['email'],
            "userType" => $_SESSION['userType'],
            "CF" => $_SESSION['CF']
        ];
        
        // Aggiungi info voto solo per cittadini
        if($_SESSION['userType'] == "Cittadino") { 
            $sessione += [
                "voto" => $_SESSION['voto'],
                "ID_seggio" =>  $_SESSION['ID_seggio']
            ];
        }

    }

    header('Content-Type: application/json');
    echo json_encode($sessione);
?>