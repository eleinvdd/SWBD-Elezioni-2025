<?php

    header('Content-Type: application/json');
    require_once($_SERVER['DOCUMENT_ROOT'] . '/swbd/PHP/index.php');

    session_start();

    $input = json_decode(file_get_contents("php://input"), true);
    $ID_seggio = $input['ID_seggio'];

    //$sessione = ["successo" => 0, "messaggio" => "Utente non autenticato"];


    //if (isset($_SESSION['ID_user']) && $_SESSION['ID_user'] == "Cittadino") {
        
        $_SESSION['ID_seggio'] = $ID_seggio;
        
        $sessione = [
            "successo" => 1,
            "messaggio" => "Seggio cambiato correttamente",
            "newSeggio" =>  $ID_seggio
        ];
    //}

    echo json_encode($sessione);
?>
