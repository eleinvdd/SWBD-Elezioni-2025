<?php
	
	require_once __DIR__ . '/Rest.php';

	class Addetti extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Addetti"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertAddetto($rowAddetto) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(nome, cognome, CF, data_nascita, ruolo, ID_seggio) 
					VALUES (?, ?, ?, ?, ?, ?)";
			
			$params = [
				$rowAddetto["nome"],
				$rowAddetto["cognome"],
				$rowAddetto["CF"],
				$rowAddetto["data_nascita"],
				$rowAddetto["ruolo"],
				$rowAddetto["ID_seggio"]
			];
			
			$types = "sssssi"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateAddetto($rowAddetto){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					nome = ?, 
					cognome = ?, 
					CF = ?, 
					data_nascita = ?, 
					ruolo = ?, 
					ID_seggio = ? 
				WHERE ID = ?";
			
			$params = [
				$rowAddetto["nome"],
				$rowAddetto["cognome"],
				$rowAddetto["CF"],
				$rowAddetto["data_nascita"],
				$rowAddetto["ruolo"],
				$rowAddetto["ID_seggio"],
				$rowAddetto["ID_addetto"],
			];

			$types = "sssssii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}

    //funzione per associare il voto al Addetto


?>