<?php
	
	require_once __DIR__ . '/Rest.php';

	class Candidati extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Candidati"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertCandidato($rowCandidato) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(nome, cognome, CF, data_nascita, ruoloCandidato, ID_lista, numCandidato) 
					VALUES (?, ?, ?, ?, ?, ?, ?)";
			
			$params = [
				$rowCandidato["nome"],
				$rowCandidato["cognome"],
				$rowCandidato["CF"],
				$rowCandidato["data_nascita"],
				$rowCandidato["ruoloCandidato"],
				$rowCandidato["ID_lista"]
			];
			
			$types = "sssssi"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateCandidato($rowCandidato){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					nome = ?, 
					cognome = ?, 
					CF = ?, 
					data_nascita = ?, 
					ruoloCandidato = ?, 
					ID_lista = ? 
				WHERE ID = ?";
			
			$params = [
				$rowCandidato["nome"],
				$rowCandidato["cognome"],
				$rowCandidato["CF"],
				$rowCandidato["data_nascita"],
				$rowCandidato["ruoloCandidato"],
				$rowCandidato["ID_seggio"],
				$rowCandidato["ID_candidato"],
			];

			$types = "sssssii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}

?>