<?php
	
	require_once __DIR__ . '/Rest.php';

	class Liste extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Liste"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertLista($rowLista) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(titolo, ID_sindaco, descrizione) 
					VALUES (?, ?, ?)";
			
			$params = [
				$rowLista["titolo"],
				$rowLista["ID_sindaco"],
				$rowLista["descrizione"]
			];
			
			$types = "sis"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateLista($rowLista){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					titolo = ?, 
					numPreferenze = ?, 
					ID_sindaco = ?, 
					descrizione = ? 
				WHERE ID = ?";
			
			$params = [
				$rowLista["titolo"],
				$rowLista["numPreferenze"],
				$rowLista["ID_sindaco"],
				$rowLista["descrizione"],
				$rowLista["ID_lista"]
			];

			$types = "siisi"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------
		
	}

?>