<?php
	require_once __DIR__ . '/../class/Cittadini.php';

	header('Content-Type: application/json');

	$api = new Cittadini();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowCittadino["ID_cittadino"] = $input['ID_cittadino'];
	$rowCittadino["nome"] = $input['nome'];
	$rowCittadino["cognome"] = $input['cognome'];
	$rowCittadino["CF"] = $input['CF'];
	$rowCittadino["data_nascita"] = $input['data_nascita'];

	$response = $api->update($rowCittadino);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>