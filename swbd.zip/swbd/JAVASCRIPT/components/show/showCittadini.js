// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Fetch dei dati
        const fetchCittadini = await fetch('http://localhost/swbd/API/cittadino/showCittadini.php');
        const cittadini = await fetchCittadini.json();
        
        
        if(cittadini.successo === 1){
            renderCittadini(cittadini.data);
        }
        else{
            if(cittadini.successo === 0) {
                console.error('Errore:', cittadini.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

async function renderCittadini(cittadini) {
    console.log("Risposta cittadini:", cittadini);

    const container = document.getElementById('cittadini-container');
    container.innerHTML = ''; // Pulisce prima

    // Creiamo il contenuto HTML per ogni candidato
    cittadini.forEach(cittadino => {
        
        const dataNascita = new Date(cittadino.data_nascita);
        const dataFormattata = dataNascita.toLocaleDateString('it-IT');
        
        //CALCOLO ETA' --------------------------------------------------------------------------------
        const oggi = new Date();
        let eta = oggi.getFullYear() - dataNascita.getFullYear();
        const mese = oggi.getMonth() - dataNascita.getMonth();
        if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
            eta--;
        }

        let votato = "null";
        if(cittadino.ID_voto){
            votato = "SI"
        }
        else{
            votato = "NO"
        }
        

        const cittadinoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${cittadino.nome} ${cittadino.cognome}</h2>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${cittadino.CF}</p>
                        <p><strong class="is-size-5">Ha votato? </strong> ${votato}</p>
                    </div>
                </div>
            </div>
        </div>
        `;

        container.insertAdjacentHTML('beforeend', cittadinoHTML);
    });
}

function showError() {
    const container = document.getElementById('liste-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento dei cittadini. Riprova più tardi.
        </div>
    `;
}