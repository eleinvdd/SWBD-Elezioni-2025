// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        
        //Fetch della sessione
        const fetchSessione = await fetch('http://localhost/swbd/PHP/config/userSession.php');
        const sessione = await fetchSessione.json();

        const parameters = {
            CF: sessione.CF     
        };

        const fetchAddetto = await fetch('http://localhost/swbd/API/addetto/readCF.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(parameters)
        });

        
        //const responseText = await fetchAddetto.text();
        //console.log("responseText della fetch addetto: ", responseText);
        

        const addetto = await fetchAddetto.json();
        
        if(sessione.successo === 1 && addetto.successo === 1){
            generaProfiloaddetto(addetto.data[0], sessione);
        }
        else{
            if(sessione.successo === 0) {
                console.error('Errore:', sessione.messaggio);
                showError();
            }
            else if (addetto.successo === 0){
                console.error('Errore:', addetto.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});



// Funzione per generare le tabelle
async function generaProfiloaddetto(addetto, sessione) {
    console.log("Risposta addetto:", addetto);
    console.log("Risposta sessione:", sessione);

    const container = document.getElementById('addetto-container');
    container.innerHTML = '';

    //TABELLA DI VOTAZIONE (una per ogni addetto) ------------------------------------------------------------------------------------
    // Seleziona le liste legate a questo addetto

    const dataNascita = new Date(addetto.data_nascita);
    const dataFormattata = dataNascita.toLocaleDateString('it-IT');
    
    //CALCOLO ETA' --------------------------------------------------------------------------------
    const oggi = new Date();
    let eta = oggi.getFullYear() - dataNascita.getFullYear();
    const mese = oggi.getMonth() - dataNascita.getMonth();
    if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
        eta--;
    }

    let addettoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${addetto.nome} ${addetto.cognome}</h2>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${addetto.CF}</p>
                        <hr class="my-5"></hr>
                        <p><strong class="is-size-5">Ruolo: </strong> ${addetto.ruolo}</p>
                    </div>
                </div>
            </div>
        </div>
    `;  
    container.insertAdjacentHTML('beforeend', addettoHTML); 

}

function showError() {
    const container = document.getElementById('addetto-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento dei candidati. Riprova più tardi.
        </div>
    `;
}