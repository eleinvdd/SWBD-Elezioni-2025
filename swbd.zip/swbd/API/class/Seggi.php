<?php
	
	require_once __DIR__ . '/Rest.php';

	class Seggi extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Seggi"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertSeggio($rowSeggio) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(comune, via, civico, numAbitanti) 
					VALUES (?, ?, ?, ?)";
			
			$params = [
				$rowSeggio["comune"],
				$rowSeggio["via"],
				$rowSeggio["civico"],
				$rowSeggio["numAbitanti"]
			];
			
			$types = "sssi"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateSeggio($rowSeggio){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					comune = ?, 
					via = ?, 
					civico = ?, 
					numAbitanti = ? 
				WHERE ID = ?";
			
			$params = [
				$rowSeggio["comune"],
				$rowSeggio["via"],
				$rowSeggio["civico"],
				$rowSeggio["numAbitanti"],
                $rowSeggio["ID_seggio"]
			];

			$types = "ssiii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}

?>