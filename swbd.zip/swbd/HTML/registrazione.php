<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Registrazione</title>
        <link rel="stylesheet" href="../CSS/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    </head>

    <header>
        <!--
        <a href="../HTML/home.php" class="title has-text-centered"><h1>HOME</h1></a>
        a<h1 class="has-text-weight-bold has-text-centered">PAGINA DI LOGIN</h1>
       -->
    </header>
    <body>


        <!-- NAVIGATION BAR -------------------------------------------------------------------------------------------------------------->
        <script src="../JAVASCRIPT/components/navbar.js"></script>

        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <!-- BREADCRUMBS ----------------------------------------------------------------------------------------------------------------->
        <!--
            <nav class="breadcrumb has-succeeds-separator py-5 px-5" aria-label="breadcrumbs">
                <ul>
                    <li><a href="../HTML/home.php">Home</a></li>
                    <li class="is-active"><a href="../HTML/registrazione.php" aria-current="page">Registrazione</a></li>
                </ul>
            </nav>
        -->
        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <section class="section">
            <div class="tabella-registrazione">
                <form action="../PHP/registrazione.php" name="registrazione" method="post">
                    <tr>
                        <th colspan="2" class="is-size-1 title">REGISTRAZIONE</th>
                    </tr>

                    <hr class="my-5"></hr>

                    <tr>
                        <td colspan="2">
                            <h1>Codice Fiscale</h1>
                            <input type="text" name="codice_fiscale">
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <h1>Email</h1>
                            <input type="email" name="email" placeholder="mario.rossi@email.com">
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <h1>Password</h1>
                            <input type="password" name="password" placeholder="password">
                        </td>
                    </tr>

                    <hr class="my-5"></hr>

                    <tr>
                        <td colspan="1">
                            <input type="button" value="Registrati" onClick="validateRegistration()">
                        </td>
                        <td colspan="1">
                            <input type="reset" name="cancella" value="Annulla">
                        </td>
                    </tr>

                </form>
            </div>
        </section>







       
        <!--  -------------------------------------------------------------------------------------------------------------->

        <!-- JAVASCRIPT ------------------------------------------------------------------------------------------------------------------>
        <script src="../JAVASCRIPT/index.js"></script>
        <script src="../JAVASCRIPT/checks/registrationChecks.js"></script>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>