<?php
	require_once __DIR__ . '/../class/Cittadini.php';

	header('Content-Type: application/json');

	$api = new Cittadini();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_cittadino = $input['ID_cittadino'];

	$response = $api->deleteFromId($ID_cittadino);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>