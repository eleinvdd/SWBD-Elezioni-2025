<?php
  session_start();
  if(!isset($_SESSION['email'])) {
  	header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/home.php");
    exit();
  }
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Addetti</title>
        <link rel="stylesheet" href="../CSS/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    </head>

    <header>
    </header>
    <body>

        <!-- NAVIGATION BAR -------------------------------------------------------------------------------------------------------------->
        <script src="../JAVASCRIPT/components/navbarAddetto.js"></script>

        <!--  ---------------------------------------------------------------------------------------------------------------------------->
       
        <!-- TUTTI I CANDIDATI---------------------------------------------------------------------------------------------------------------------------->
        <section class="section" >
          <div id="addetto-container" class="tabella-addetto">
            <!-- I candidati verranno caricate qui dinamicamente -->
          </div>
        </section>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->

        <!-- JAVASCRIPT ------------------------------------------------------------------------------------------------------------------>
        <script src="../JAVASCRIPT/index.js"></script>
        <script src="../JAVASCRIPT/components/show/showProfile/showProfileAddetto.js"></script>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>