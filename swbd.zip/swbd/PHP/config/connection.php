<?php
    //header("Access-Control-Allow-Origin: *");
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "elezioni_2025";
    $port = 3306;
    
    $conn;

    try {
        $conn = new mysqli($host, $user, $password, $database, $port);
    
        // Verifica connessione
        if ($conn->connect_errno) {
            throw new Exception("Connessione fallita: " . $conn->connect_error);
        }
        
        // Verifica che il database esista
        if (!$conn->select_db($database)) {
            throw new Exception("Database non trovato: " . $database);
        }

        // Imposta charset
        if (!$conn->set_charset("utf8mb4")) {
            throw new Exception("Errore charset: " . $conn->error);
        }
    } 
    catch (Exception $e) {
        // Logga l'errore (sicuro per produzione)
        error_log($e->getMessage());
        
        // Messaggio generico all'utente
        die("Errore di sistema. Riprova più tardi.");
        
        // Per debug (mostra l'errore completo)
        // die($e->getMessage()); 
    }

?>