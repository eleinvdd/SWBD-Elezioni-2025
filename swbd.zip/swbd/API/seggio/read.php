<?php
	require_once __DIR__ . '/../class/Seggi.php';

	header('Content-Type: application/json');

	$api = new Seggi();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_seggio = $input['ID_seggio'];
	$response = $api->getRows($ID_seggio);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>