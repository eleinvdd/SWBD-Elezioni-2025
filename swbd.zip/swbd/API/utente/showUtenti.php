<?php
	
	require_once __DIR__ . '/../class/Utenti.php';

    $api = new Utenti();
    
    $response = $api->getRows(null);

    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);

?>