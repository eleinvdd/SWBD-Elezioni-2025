// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        
        //Fetch della sessione
        const fetchSessione = await fetch('http://localhost/swbd/PHP/config/userSession.php');
        const sessione = await fetchSessione.json();

        const parameters = {
            CF: sessione.CF     
        };

        const fetchSindaco = await fetch('http://localhost/swbd/API/sindaco/readCF.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(parameters)
        });

        
        //const responseText = await fetchSindaco.text();
        //console.log("responseText della fetch sindaco: ", responseText);
        

        const sindaco = await fetchSindaco.json();
        
        if(sessione.successo === 1 && sindaco.successo === 1){
            generaProfilosindaco(sindaco.data[0], sessione);
        }
        else{
            if(sessione.successo === 0) {
                console.error('Errore:', sessione.messaggio);
                showError();
            }
            else if (sindaco.successo === 0){
                console.error('Errore:', sindaco.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});



// Funzione per generare le tabelle
async function generaProfilosindaco(sindaco, sessione) {
    console.log("Risposta sindaco:", sindaco);
    console.log("Risposta sessione:", sessione);

    const container = document.getElementById('sindaco-container');
    container.innerHTML = '';

    //TABELLA DI VOTAZIONE (una per ogni sindaco) ------------------------------------------------------------------------------------
    // Seleziona le liste legate a questo sindaco

    const dataNascita = new Date(sindaco.data_nascita);
    const dataFormattata = dataNascita.toLocaleDateString('it-IT');
    
    //CALCOLO ETA' --------------------------------------------------------------------------------
    const oggi = new Date();
    let eta = oggi.getFullYear() - dataNascita.getFullYear();
    const mese = oggi.getMonth() - dataNascita.getMonth();
    if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
        eta--;
    }

    let sindacoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${sindaco.nome} ${sindaco.cognome}</h2>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${sindaco.CF}</p>
                        <hr class="my-5"></hr>
                        <p><strong class="is-size-5">Preferenze: </strong> ${sindaco.numPreferenze}</p>
                    </div>
                </div>
            </div>
        </div>
    `;  
    container.insertAdjacentHTML('beforeend', sindacoHTML); 

}

function showError() {
    const container = document.getElementById('sindaco-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento dei candidati. Riprova più tardi.
        </div>
    `;
}