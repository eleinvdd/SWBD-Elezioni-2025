<?php
	require_once __DIR__ . '/../class/Liste.php';

	header('Content-Type: application/json');

	$api = new Liste();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowLista["titolo"] = $input['titolo'];
	$rowLista["ID_sindaco"] = $input['ID_sindaco'];
	$rowLista["descrizione"] = $input['descrizione'];

	$response = $api->insertLista($rowLista);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>