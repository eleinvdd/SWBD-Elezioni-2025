// Funzione generica per le chiamate API
// Chiamata iniziale
document.addEventListener('DOMContentLoaded', () => {
    loadAllData().catch(error => {
        console.error('Errore nel caricamento dati:', error);
    });
});

async function fetchData(url) {

    try {
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.successo === 1) {
            //renderFunction(data.data);
        } else {
            console.error('Errore API:', data.messaggio || 'Errore sconosciuto');
            showError(data.messaggio);
        }
        return data; // Opzionale: restituisce i dati per ulteriori elaborazioni
    } catch (error) {
        console.error(`Errore fetch ${url}:`, error);
        showError('Errore di connessione al server');
        throw error; // Rilancia l'errore per gestione esterna
    }
}

// Utilizzo
async function loadAllData() {
    // Versione con chiamate sequenziali
    const fetch_sindaci = await fetchData('http://localhost/swbd/API/sindaco/read.php');
    const sindaci = await fetch_sindaci.json();

    const fetch_liste = await fetchData('http://localhost/swbd/API/lista/read.php');
    const liste = await fetch_liste.json();

    const fetch_candidati = await fetchData('http://localhost/swbd/API/candidato/read.php');
    const candidati = await fetch_candidati.json();

    renderBoxVotazione(sindaci, liste, candidati);
}

function renderBoxVotazione(sindaci, liste, candidati){

    var sindacoHTML;
    var listaHTML;
    var candidatoHTML;

    //PER OGNI SINDACO STAMPARE LE LISTE
            //PER OGNI LISTA STAMPARE I CANDIDATI
                //PER candidato...

    sindaci.forEach(sindaco => {
        sindacoHTML = '<h1 class="is-size-1 title">${sindaco.nome} ${sindaco.cognome} </h1>';

        liste.forEach(lista => {
            listaHTML = '<p class="is-size-3 subtitle">${list.titolo}</h1>';

            candidati.forEach(candidato => {
                candidatoHTML = '<p class="is-size-6">${candidato.nome} ${candidato.cognome} </h1>';


            });//candidati
        });//liste
    });//sindaci


/*
    function generaMenuCandidati(candidati, containerId, selectId = 'candidati-select', onChangeCallback) {
        
        // 1. Recupera il container
        const container = document.getElementById(containerId);

        // 2. Crea l'elemento select
        const select = document.createElement('select');
        select.id = selectId;
        select.className = 'select-candidati'; // Classe per lo stile

        // 3. Aggiungi opzione di default
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = 'Seleziona un candidato...';
        defaultOption.selected = true;
        defaultOption.disabled = true;
        select.appendChild(defaultOption);

        // 4. Popola il menu con i candidati
        candidati.forEach(candidato => {
            const option = document.createElement('option');
            option.value = candidato.ID; // Usa l'ID come valore
            option.textContent = `${candidato.nome} ${candidato.cognome}`;
            
            select.appendChild(option);
        });

        // 5. Gestisci l'evento change
        select.addEventListener('change', function() {
            const selectedId = this.value;
            const selectedCandidate = candidati.find(c => c.ID == selectedId);
            
            if (onChangeCallback && selectedId) {
                onChangeCallback(selectedCandidate);
            }
        });

        // 6. Aggiungi al DOM
        container.innerHTML = ''; // Pulisci il container
        container.appendChild(select);
    }

    // Chiamata alla funzione
    generaMenuCandidati(
        candidatiEsempio,
        'candidati-container',
        'menu-candidati',
        function(candidatoSelezionato) {
            console.log('Candidato selezionato:', candidatoSelezionato);
            // Aggiungi qui la tua logica
        }
    );
*/





}

