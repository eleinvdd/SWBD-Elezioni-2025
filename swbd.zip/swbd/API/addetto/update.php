<?php
	require_once __DIR__ . '/../class/Addetti.php';

	header('Content-Type: application/json');

	$api = new Addetti();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowAddetto["ID_addetto"] = $input['ID_addetto'];
	$rowAddetto["nome"] = $input['nome'];
	$rowAddetto["cognome"] = $input['cognome'];
	$rowAddetto["CF"] = $input['CF'];
	$rowAddetto["data_nascita"] = $input['data_nascita'];
	$rowAddetto["ruolo"] = $input['ruolo'];
	$rowAddetto["ID_seggio"] = $input['ID_seggio'];

	$response = $api->updateAddetto($rowAddetto);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>