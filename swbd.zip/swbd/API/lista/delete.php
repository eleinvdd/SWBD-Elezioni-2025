<?php
	require_once __DIR__ . '/../class/Liste.php';

	header('Content-Type: application/json');

	$api = new Liste();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_lista = $input['ID_lista'];

	$response = $api->deleteFromId($ID_lista);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>