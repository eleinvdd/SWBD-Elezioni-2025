document.write(`
<nav class="navbar has-shadow">
    <div class="logo">
        <a class="navbar-item" href="../HTML/home.php">
            <img src="../media/logo_bianco.png" alt="logoVanvitelliBianco" style="max-height: 70px;" class="py-2 px-2">
        </a>
    </div>

    <a class="navbar-burger" id="burger">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </a>

    <div class="navbar-menu" id="nav-links">
    
        <div class="navbar-start">
            <a class="navbar-item" href="../HTML/admin/admin.php">Admin</a>
            <a class="navbar-item" href="../HTML/liste.php">Liste</a>
        </div>
        <div class="navbar-end">   
            <a class="navbar-item" href="../HTML/registrazione.php">Registrazione</a>
            <a class="navbar-item" href="../HTML/login.php">Login</a>
        </div>
    </div>
</nav>
`);