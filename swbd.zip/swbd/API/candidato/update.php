<?php
	require_once __DIR__ . '/../class/Candidati.php';

	header('Content-Type: application/json');

	$api = new Candidati();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowCandidato["ID_candidato"] = $input['ID_candidato'];
	$rowCandidato["nome"] = $input['nome'];
	$rowCandidato["cognome"] = $input['cognome'];
	$rowCandidato["CF"] = $input['CF'];
	$rowCandidato["data_nascita"] = $input['data_nascita'];
	$rowCandidato["ruolo"] = $input['ruolo'];
	$rowCandidato["ID_seggio"] = $input['ID_seggio'];

	$response = $api->updateCandidato($rowCandidato);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>