-- VOTAZIONE "candidato" ------------------------
DELIMITER $$

CREATE TRIGGER votazioneCandidato
AFTER INSERT ON VotiCandidato
FOR EACH ROW
BEGIN
    
    CALL incrementaPreferenzeCandidato(NEW.ID_candidato);
    
END$$

DELIMITER ;
-- -------------------------------------------------------------

-- VOTAZIONE "lista" ------------------------
DELIMITER $$

CREATE TRIGGER votazioneLista
AFTER INSERT ON VotiLista
FOR EACH ROW
BEGIN
    
    CALL incrementaPreferenzeLista(NEW.ID_lista);

END$$

DELIMITER ;
-- -------------------------------------------------------------

-- VOTAZIONE "sindaco" in INSERT------------------------
DELIMITER $$

CREATE TRIGGER votazioneSindaco
AFTER INSERT ON Voti
FOR EACH ROW
BEGIN

    CALL incrementaPreferenzeSindaco(NEW.ID_sindaco);

END$$

DELIMITER ;
-- -------------------------------------------------------------

-- CONTROLLO UNICO "supervisore" in INSERT --------------
DELIMITER $$

CREATE TRIGGER checkSupervisoreUnico_INSERT
BEFORE INSERT ON Addetti
FOR EACH ROW
BEGIN
    DECLARE error_message VARCHAR(255);
    
    IF NEW.ruolo = 'Supervisore' THEN
        IF EXISTS (
            SELECT 1 FROM Addetti
            WHERE ID_seggio = NEW.ID_seggio
              AND ruolo = 'Supervisore'
        ) THEN
            SET error_message = CONCAT('Il seggio ', NEW.ID_seggio, ' può avere al massimo un supervisore.');
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
        END IF;
    END IF;
END$$

DELIMITER ;

-- ------------------------------------------------------

-- CONTROLLO UNICO "supervisore" in UPDATE --------------
DELIMITER $$

CREATE TRIGGER checkSupervisoreUnico_UPDATE
BEFORE UPDATE ON Addetti
FOR EACH ROW
BEGIN
		DECLARE error_message VARCHAR(255);
    
    IF NEW.ruolo = 'Supervisore' THEN
        IF EXISTS (
            SELECT 1 FROM Addetti
            WHERE ID_seggio = NEW.ID_seggio
              AND ruolo = 'Supervisore'
          		-- escludo sè stesso
          		AND ID <> NEW.ID
        ) THEN
            SET error_message = CONCAT('Il seggio ', NEW.ID_seggio, ' può avere al massimo un supervisore.');
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
        END IF;
    END IF;
END$$

DELIMITER ;

-- ------------------------------------------------------


-- ASSOCIAZIONE Utente a "persona" ------------------------
DELIMITER $$

CREATE TRIGGER associazioneUtente
AFTER INSERT ON Utenti
FOR EACH ROW
BEGIN
    
    CALL associaUtente(NEW.ID, NEW.userType, NEW.CF);

END$$

DELIMITER ;
-- -------------------------------------------------------------

-- incremento numCandidato ------------------------
DELIMITER $$

CREATE TRIGGER incrementaNumCandidato
BEFORE INSERT ON Candidati
FOR EACH ROW
BEGIN
    DECLARE max_num INT;

    -- Trova il massimo numCandidato per la lista specifica
    SELECT IFNULL(MAX(numCandidato), 0)
    INTO max_num
    FROM Candidati
    WHERE ID_lista = NEW.ID_lista;

    -- Assegna il valore successivo
    SET NEW.numCandidato = max_num + 1;
END$$

DELIMITER ;
-- -------------------------------------------------------------
