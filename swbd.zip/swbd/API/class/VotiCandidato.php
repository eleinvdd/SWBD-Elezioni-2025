<?php
	
	require_once __DIR__ . '/Rest.php';

	class VotiCandidato extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "VotiCandidato"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertVotoCandidato($rowVotoCandidato) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(ID_voto, ID_candidato) 
					VALUES (?, ?)";
			
			$params = [
				$rowVotoCandidato["ID_voto"],
				$rowVotoCandidato["ID_candidato"],
			];
			
			$types = "ii"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateVotoCandidato($rowVotoCandidato){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					ID_voto = ?, 
					ID_candidato = ? 
				WHERE ID_voto = ?";
			
			$params = [
				$rowVotoCandidato["ID_voto"],
				$rowVotoCandidato["ID_candidato"],
				$rowVotoCandidato["ID_voto"]
			];
			
			$types = "iii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}


?>