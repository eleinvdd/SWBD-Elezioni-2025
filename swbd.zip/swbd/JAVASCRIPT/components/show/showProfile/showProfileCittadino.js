// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        
        //Fetch della sessione
        const fetchSessione = await fetch('http://localhost/swbd/PHP/config/userSession.php');
        const sessione = await fetchSessione.json();
        
        // Fetch dei dati
        const fetchSeggi = await fetch('http://localhost/swbd/API/seggio/showSeggi.php');
        const seggi = await fetchSeggi.json();


        const parameters = {
            CF: sessione.CF     
        };

        const fetchCittadino = await fetch('http://localhost/swbd/API/cittadino/readCF.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(parameters)
        });

        /*
        const responseText = await fetchCittadino.text();
        console.log("responseText della fetch cittadino: ", responseText);
        */

        const cittadino = await fetchCittadino.json();
        
        if(sessione.successo === 1 && cittadino.successo === 1 && seggi.successo === 1){
            generaProfiloCittadino(cittadino.data[0], sessione, seggi.data);
        }
        else{
            if(sessione.successo === 0) {
                console.error('Errore:', sessione.messaggio);
                showError();
            }
            else if (cittadino.successo === 0){
                console.error('Errore:', cittadino.messaggio);
                showError();
            }
            else if (seggi.successo === 0){
                console.error('Errore:', seggi.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});



// Funzione per generare le tabelle
// Funzione per generare le tabelle
async function generaProfiloCittadino(cittadino, sessione, seggi) {
    console.log("Risposta cittadino:", cittadino);
    console.log("Risposta sessione:", sessione);
    console.log("Risposta seggio:", sessione);

    const container = document.getElementById('cittadino-container');
    container.innerHTML = '';

    //TABELLA DI VOTAZIONE (una per ogni sindaco) ------------------------------------------------------------------------------------
    // Seleziona le liste legate a questo sindaco

    const dataNascita = new Date(cittadino.data_nascita);
    const dataFormattata = dataNascita.toLocaleDateString('it-IT');
    
    //CALCOLO ETA' --------------------------------------------------------------------------------
    const oggi = new Date();
    let eta = oggi.getFullYear() - dataNascita.getFullYear();
    const mese = oggi.getMonth() - dataNascita.getMonth();
    if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
        eta--;
    }


    let votato = "null";
    if(sessione.voto){
        votato = "SI"
    }
    else{
        votato = "NO"
    }


    //GENERO LA LISTA DEI SEGGI (SCOMPARE NEL CASO IL CITTADINO ABBIA GIA' VOTATO) --------------------------------------------------
    let seggiHTML='';
    if(!sessione.voto){        
        seggiHTML += `
            <select id="select-seggio">
        `;

        seggi.forEach(seggio => {
            seggiHTML += `
                <option value="${seggio.ID}">
                    ${seggio.comune} - ${seggio.via} ${seggio.civico} (${seggio.numAbitanti} abitanti)
                </option>
            `;
        });

        seggiHTML += `
            </select>
        `;
    }
    // --------------------------------------------------

    let cittadinoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${cittadino.nome} ${cittadino.cognome}</h2>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${cittadino.CF}</p>
                        <p><strong class="is-size-5">Hai votato? </strong> ${votato}</p>
                        <hr class="my-5"></hr>
                        ${seggiHTML}
                        <!-- la select dei seggi verrà inserita qui -->
                    </div>
                </div>
            </div>
        </div>
    `;

    
    container.insertAdjacentHTML('beforeend', cittadinoHTML);

    if(!sessione.voto){        
        const selezioneSeggio = document.getElementById(`select-seggio`);
        selezioneSeggio.addEventListener('change', async function() {
            const seggioID = this.value;

            const parameter = {           
                ID_seggio: seggioID
            };

            console.log("Dati del seggio da inviare:", parameter);

            try {
                const fetchChangeSeggio = await fetch('http://localhost/swbd/PHP/config/changeSeggio.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(parameter)
                });
                
                /*
                const responseText = await fetchChangeSeggio.text();
                console.log("responseText della fetch changeSeggio: ", responseText);
                */
                const changeSeggio = await fetchChangeSeggio.json();
                console.log(changeSeggio);
                
                if (changeSeggio.successo === 1) {
                    console.log("Seggio modificato con successo:", changeSeggio.newSeggio);
                } else {
                    alert("Errore durante la modifica del seggio: " + (changeSeggio.message || ""));
                }
                    
            } catch (error) {
                //console.log("la response:", changeSeggio.successo);
                alert("Errore di connessione: " + error.message);
            }

        });
    }
    

}

function showError() {
    const container = document.getElementById('cittadino-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento dei cittadini. Riprova più tardi.
        </div>
    `;
}