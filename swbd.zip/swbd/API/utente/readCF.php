<?php
	require_once __DIR__ . '/../class/Utenti.php';

	header('Content-Type: application/json');

	$api = new Utenti();
	$input = json_decode(file_get_contents("php://input"), true);

	$CF = $input['CF'];
	$response = $api->getFromCF($CF);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>