<?php
	class Rest{

		//ATTRIBUTI -------------------------------------------------------------------------
		protected $host  = 'localhost';
		protected $user  = 'root';
		protected $password   = "";
		protected $database  = "elezioni_2025";      
		protected $tabella = '';	
		protected $dbConnect = false;
		//--------- -------------------------------------------------------------------------

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct(){

			//effettuo la connessione quando viene istanziato un oggetto
			if(!$this->dbConnect){ 
				
				$conn = new mysqli($this->host, $this->user, $this->password, $this->database);
				
				if($conn->connect_error){
					die("Errore nella connessione al database MySQL: " . $conn->connect_error);
				}else{
					$this->dbConnect = $conn;
				}
			}
		}
		//--------- -------------------------------------------------------------------------

		//--------- -------------------------------------------------------------------------
		protected function getDati($sqlQuery) {
			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			
			if(!$result){
				die('Errore nella query: '. mysqli_error());
			}

			$data= array();

			while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
				$data[]=$row;            
			}

			return $data;
		}
		//--------- -------------------------------------------------------------------------
		
		//--------- -------------------------------------------------------------------------
		protected function getNumeroRighe($sqlQuery) {
			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			
			if(!$result){
				die('Errore nella query: '. mysqli_error());
			}

			$numRows = mysqli_num_rows($result);
			return $numRows;
		}
		//--------- -------------------------------------------------------------------------

		//--------- -------------------------------------------------------------------------
		public function getRows($id = null) {
			
			$query = "SELECT * FROM " . $this->tabella;
			$params = [];
			$types = '';

			if ($id !== null) {
				$query .= " WHERE ID = ?";
				$params[] = $id;
				$types = "i"; // 'i' per ID intero
			}

			$query .= " ORDER BY ID ASC";
			$stmt = $this->dbConnect->prepare($query);

			if (!$stmt) {
				$response = ['successo' => 0, 'messaggio' => 'Errore preparazione query: ' . $this->dbConnect->error];
				return $response;
			}
			else{

			}
			if (!empty($params)) {
				$stmt->bind_param($types, ...$params);
			}

			if (!$stmt->execute()) {
				$response = ['successo' => 0, 'messaggio' => "Errore: " . $stmt->error];
				return $response;
			}

			$result = $stmt->get_result();
			$data = $result->fetch_all(MYSQLI_ASSOC);
			$stmt->close();

			$response = [
					'successo' => 1,
					'data' => $data
			];

			return $response;
		}
		//--------- -------------------------------------------------------------------------


		//CRUD -------------------------------------------------------------------------
		protected function iudQuery($query, $params = [], $types = '') {
			
			$stmt = $this->dbConnect->prepare($query);
			
			if(!$stmt){
				$response = ['successo' => 0, 'messaggio' => "Errore: nella preparazione query"];
				return $response;
			}

			if (!empty($params)) {
				$stmt->bind_param($types, ...$params);
			}
			
			$executeResult = $stmt->execute();

			if ($executeResult) {
				$response = ['successo' => 1, 'messaggio' => "Operazione riuscita"];
				$response['affected_rows'] = $stmt->affected_rows;
				
				// Solo per INSERT restituisce l'ID autoincrement
				if (stripos($query, 'INSERT') === 0) {
					$response['insert_id'] = $stmt->insert_id;
				}
				
				/*
				// Per SELECT restituisce i dati (se necessario)
				if (stripos($query, 'SELECT') === 0) {
					$result = $stmt->get_result();
					$response['data'] = $result->fetch_all(MYSQLI_ASSOC);
					$response['num_rows'] = $result->num_rows;
				}
				*/

			} else {
				$response = ['successo' => 0, 'messaggio' => "Errore: " . $stmt->error];
			}
			
			
			/*
			$response = ['successo', 'messaggio', 'affected_rows', 'insert_id'];
			*/

			$stmt->close();
			return $response;

		}
		//--------- ------------------------------------------------------------------------

		//DELETE -------------------------------------------------------------------------
		public function deleteFromId($id) {		
			
			//DOVREI PRENDERE SOLO ID COME PARAMETRO E VERIFICARE SE è VUOTO O MENO
			if(empty($id)){
				$response = ['successo' => 0, 'messaggio' => "ID mancante"];
			}
			else{
				$query = "
					DELETE FROM ".$this->tabella." 
					WHERE ID = ?";

				$params = [
					$id
				];

				$types = "i"; // s=stringa, i=intero
				
				$response = $this->iudQuery($query, $params, $types);
			}
			

			return $response;
		}
		//--------- -------------------------------------------------------------------------


		//GET (opzionale posso usare anche solo getRows con ID come parametro) -------------
		public function getFromCF($CF) {

			$response =['successo' => 0, 'messaggio' => "L'oggetto non rappresenta una persona"];

			if($this->tabella == "Cittadini" || $this->tabella == "Addetti" || $this->tabella ==  "Candidati" || $this->tabella == "Sindaci"){
				
				$query = "SELECT * FROM " . $this->tabella . " WHERE CF = ?";
				$params[] = $CF;
				$types = "s";

				$stmt = $this->dbConnect->prepare($query);

				if (!$stmt) {
					$response = ['successo' => 0, 'messaggio' => 'Errore preparazione query: ' . $this->dbConnect->error];
					return $response;
				}
				else{

				}
				if (!empty($params)) {
					$stmt->bind_param($types, ...$params);
				}

				if (!$stmt->execute()) {
					$response = ['successo' => 0, 'messaggio' => "Errore: " . $stmt->error];
					return $response;
				}

				$result = $stmt->get_result();
				$data = $result->fetch_all(MYSQLI_ASSOC);
				$stmt->close();

				$response = [
						'successo' => 1,
						'data' => $data
				];
			}
			
			return $response;
		}
		
		//--------- -------------------------------------------------------------------------
		/*
		//GET (opzionale posso usare anche solo getRows con ID come parametro) -------------
		public function getFromId($id) {
			
            $result = $this->getRows($id);

			if (isset($result['successo']) && $result['successo'] === 0) {
				$response = [
					'successo' => 0,
					'messaggio' => $result['messaggio']
				];
			} 
			else {
				$response = [
					'successo' => 1,
					'data' => $result
				];
			}

			return $response;
		}
		*/
		//--------- -------------------------------------------------------------------------

		/*
		//INSERT -------------------------------------------------------------------------
		protected function insertRow($query, $params = [], $types = '') {
			$stmt = $this->dbConnect->prepare($query);
			
			if (!empty($params)) {
				$stmt->bind_param($types, ...$params);
			}
			
			if ($stmt->execute()) {
				$response = ['successo' => 1, 'messaggio' => "Inserimento effettuato"];
			} else {
				$response = ['successo' => 0, 'messaggio' => "Errore: " . $stmt->error];
			}
			
			$stmt->close();
			header('Content-Type: application/json');
			echo json_encode($response, JSON_PRETTY_PRINT);
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		protected function updateRow($id, $query){ 	

			if($id){
				
				if( mysqli_query($this->dbConnect, $query)) {
					$messaggio = "aggiornamento effettuato con successo.";
					$successo = 1;			
				} 

				else {
					$messaggio = "aggiornamento fallito.";
					$successo = 0;			
				}
			}

			else {
				$messaggio = "Richiesta non valida.";
				$successo = 0;
			}
			

			$response = array(
				'successo' => $successo,
				'messaggio' => $messaggio
			);

			header('Content-Type: application/json');
			echo json_encode($response, JSON_PRETTY_PRINT);
		}
		//--------- -------------------------------------------------------------------------

		//DELETE -------------------------------------------------------------------------
		public function deleteRow($id, $query) {		
			if($id){
				
				if( mysqli_query($this->dbConnect, $query)) {
					$messaggio = "eliminazione effettuata con successo.";
					$successo = 1;			
				} 

				else {
					$messaggio = "eliminazione fallita.";
					$successo = 0;			
				}
			}

			else {
				$messaggio = "Richiesta non valida.";
				$successo = 0;
			}
			
			$response = array(
				'successo' => $successo,
				'messaggio' => $messaggio
			);

			header('Content-Type: application/json');
			echo json_encode($response, JSON_PRETTY_PRINT);	
		}
		//--------- -------------------------------------------------------------------------
		*/
	}

?>