<?php
	require_once __DIR__ . '/../class/VotiLista.php';

	header('Content-Type: application/json');

	$api = new VotiLista();
	$input = json_decode(file_get_contents("php://input"), true);

	$ID_voto = $input['ID_voto'];
	$response = $api->getRows($ID_voto);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>