<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Liste</title>
        <!-- <link rel="stylesheet" href="../../CSS/style.css"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    </head>

    <header>
        <!--
        <a href="../HTML/home.php" class="title has-text-centered"><h1>HOME</h1></a>
        a<h1 class="has-text-weight-bold has-text-centered">PAGINA DI LOGIN</h1>
       -->
    </header>
    <body>

        <!-- NAVIGATION BAR -------------------------------------------------------------------------------------------------------------->
        <script src="navbarAdmin.js"></script>

        <section class="section" id="liste-container">
            <!-- Le liste verranno caricate qui dinamicamente -->
        </section>


        <!-- JAVASCRIPT ------------------------------------------------------------------------------------------------------------------>
        <script src="../../JAVASCRIPT/index.js"></script>
        <script src="../../JAVASCRIPT/components/show/showListe.js"></script>
        <!--  ---------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>