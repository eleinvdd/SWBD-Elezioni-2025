<?php
	require_once __DIR__ . '/../class/Sindaci.php';

	header('Content-Type: application/json');

	$api = new Sindaci();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowSindaco["nome"] = $input['nome'];
	$rowSindaco["cognome"] = $input['cognome'];
	$rowSindaco["CF"] = $input['CF'];
	$rowSindaco["data_nascita"] = $input['data_nascita'];
	$rowSindaco["ID_sindaco"] = $input['ID_sindaco'];

	$response = $api->updateSindaco($rowSindaco);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>