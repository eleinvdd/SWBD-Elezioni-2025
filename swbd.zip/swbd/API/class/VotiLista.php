<?php
	
	require_once __DIR__ . '/Rest.php';

	class VotiLista extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "VotiLista"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertVotoLista($rowVotoLista) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(ID_voto, ID_lista) 
					VALUES (?, ?)";
			
			$params = [
				$rowVotoLista["ID_voto"],
				$rowVotoLista["ID_lista"],
			];
			
			$types = "ii"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateVotoLista($rowVotoLista){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					ID_voto = ?, 
					ID_lista = ? 
				WHERE ID_voto = ?";
			
			$params = [
				$rowVotoLista["ID_voto"],
				$rowVotoLista["ID_lista"],
				$rowVotoLista["ID_voto"]
			];
			
			$types = "iii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}


?>