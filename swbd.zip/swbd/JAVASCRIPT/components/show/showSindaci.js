
// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Fetch dei dati
        const fetchSindaci = await fetch('http://localhost/swbd/API/sindaco/showSindaci.php');
        const sindaci = await fetchSindaci.json();
        
        const fetchListe = await fetch('http://localhost/swbd/API/lista/showListe.php');
        const liste = await fetchListe.json();
        
        if(sindaci.successo === 1 && liste.successo === 1){
            renderSindaci(sindaci.data, liste.data);
        }
        else{
            if(sindaci.successo === 0) {
                console.error('Errore:', sindaci.messaggio);
                showError();}
            else if (liste.successo === 0){
                console.error('Errore:', liste.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

async function renderSindaci(sindaci, liste) {

    console.log("Risposta sindaci:", sindaci);
    console.log("Risposta liste:", liste);

    const container = document.getElementById('sindaci-container');
    container.innerHTML = ''; // Pulisce prima

    sindaci.forEach(sindaco => {
        // Seleziona le liste legate a questo sindaco
        const listeDelSindaco = liste.filter(lista => lista.ID_sindaco == sindaco.ID);

        const dataNascita = new Date(sindaco.data_nascita);
        const dataFormattata = dataNascita.toLocaleDateString('it-IT');
        
        //CALCOLO ETA' --------------------------------------------------------------------------------
        const oggi = new Date();
        let eta = oggi.getFullYear() - dataNascita.getFullYear();
        const mese = oggi.getMonth() - dataNascita.getMonth();
        if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
            eta--;
        }

        let sindacoHTML = `
        <div class="box">
            <h2 class="title is-3">${sindaco.nome} ${sindaco.cognome}</h2>
            <h3 class="subtitle is-5">Preferenze: ${sindaco.numPreferenze}</h3>
            <hr class="my-5"></hr>
            <div class="content">
                <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                <p><strong class="is-size-5">Codice Fiscale:</strong> ${sindaco.CF}</p>
                <hr class="my-5"></hr>        
        `;

        listeDelSindaco.forEach(lista => {
            sindacoHTML += `
                    <p><strong class="is-size-4">Lista:</strong> ${lista.titolo} (preferenze: ${lista.numPreferenze})</p>
            `;
        });

        sindacoHTML += '</div>';
        container.insertAdjacentHTML('beforeend', sindacoHTML);
    });
}

function showError() {
    const container = document.getElementById('liste-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento delle liste. Riprova più tardi.
        </div>
    `;
}
