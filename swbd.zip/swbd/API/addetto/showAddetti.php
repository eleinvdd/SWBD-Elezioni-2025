<?php
	
	require_once __DIR__ . '/../class/Addetti.php';

    $api = new Addetti();
    $response = $api->getRows(null);

    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);

?>