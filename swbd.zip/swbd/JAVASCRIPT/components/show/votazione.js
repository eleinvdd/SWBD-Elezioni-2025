// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        
        //Fetch della sessione
        const fetchSessione = await fetch('http://localhost/swbd/PHP/config/userSession.php');
        const sessione = await fetchSessione.json();

        // Fetch dei dati
        const fetchSindaci = await fetch('http://localhost/swbd/API/sindaco/showSindaci.php');
        const sindaci = await fetchSindaci.json();
        
        const fetchListe = await fetch('http://localhost/swbd/API/lista/showListe.php');
        const liste = await fetchListe.json();
        
        const fetchCandidati = await fetch('http://localhost/swbd/API/candidato/showCandidati.php');
        const candidati = await fetchCandidati.json();
        
        if(sindaci.successo === 1 && liste.successo === 1 && candidati.successo === 1 && sessione.successo === 1){
            generaTabelle(sindaci, liste, candidati, sessione);
        }
        else{
            if(sindaci.successo === 0) {
                console.error('Errore:', sindaci.messaggio);
                showError();
            }
            else if (liste.successo === 0){
                console.error('Errore:', liste.messaggio);
                showError();
            }
            else if (candidati.successo === 0){
                console.error('Errore:', candidati.messaggio);
                showError();
            }
            else if (sessione.successo === 0){
                console.error('Errore:', sessione.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});



// Funzione per generare le tabelle
// Funzione per generare le tabelle
async function generaTabelle(sindaci, liste, candidati, sessione) {
    console.log("Risposta sindaci:", sindaci);
    console.log("Risposta liste:", liste);
    console.log("Risposta candidati:", candidati);
    console.log("Risposta sessione:", sessione);

    const container = document.getElementById('tabelle-sindaci');
    container.innerHTML = '';

    //TABELLA DI VOTAZIONE (una per ogni sindaco) ------------------------------------------------------------------------------------
    sindaci.data.forEach(sindaco => {
        const listeSindaco = liste.data.filter(lista => lista.ID_sindaco == sindaco.ID);

        // Crea la tabella per il sindaco
        const tabellaSindaco = document.createElement('table');
        tabellaSindaco.className = 'tabella-sindaco';
        tabellaSindaco.id = `tabella-sindaco-${sindaco.ID}`; // Assegna ID alla tabella

        // Riga 1: Nome e Cognome del Sindaco
        tabellaSindaco.innerHTML += `
            <tr>
                <th colspan="2" class="is-size-3">Sindaco</th>
            </tr>
            <tr>
                <td rowspan="2" colspan="2" id="nomeSindaco-${sindaco.ID} class="title">${sindaco.nome} ${sindaco.cognome}</td>
            </tr>
            <hr class="my-5"></hr>
        `;

        // Riga 2: Menù a tendina per la lista
        tabellaSindaco.innerHTML += `
            <tr>
                <th colspan="2" class="is-size-3">Lista Associata</th>
            </tr>
            <tr>
                <td colspan="2">
                    <select id="selezioneLista-${sindaco.ID}" class="subtitle select-lista">
                        <option value="">-- Seleziona una lista --</option>
                        ${listeSindaco.map(lista => 
                            `<option class="has-centered-text" value="${lista.ID}">${lista.titolo}</option>`
                        ).join('')}
                    </select>
                </td>
            </tr>
            <hr class="my-5"></hr>
        `;

        // Riga 3: Candidati (vuota inizialmente)
        tabellaSindaco.innerHTML += `
            <tr>
                <th colspan="2" class="is-size-3"></th>
            </tr>
            <tr id="candidatiSindaco-${sindaco.ID}">
                <td colspan="2" class="is-size-6">(seleziona una lista per visualizzare i candidati).</td>
            </tr>
            <hr class="my-5"></hr>
        `;

        //SE L'UTENTE HA GIA' VOTATO NON VISUALIZZO IL PULSANTE PER ESPRIMERE LA VOTAZIONE
        if(!sessione.voto){
            // Riga 4: Bottone "Vota"
            tabellaSindaco.innerHTML += `
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <button id="vota-btn-${sindaco.ID}" class="vota-btn is-size-2">VOTA</button>
                    </td>
                </tr>
            `;
        }
            

        container.appendChild(tabellaSindaco);
    });
    
    // Riga 3: VISUALIZZO I CANDIDATI IN BASE ALLA LISTA ------------------------------------------------------------------------------------
    sindaci.data.forEach(sindaco => {
        const selezioneLista = document.getElementById(`selezioneLista-${sindaco.ID}`);
        selezioneLista.addEventListener('change', function() {
            const listaId = this.value;
            const rigaCandidati = document.getElementById(`candidatiSindaco-${sindaco.ID}`);

            if (!listaId) {
                rigaCandidati.innerHTML = '<td colspan="2" class="is-size-6">(seleziona una lista per visualizzare i candidati).</td>';
                return;
            }

            // Filtra i candidati
            const candidatiLista = candidati.data.filter(candidato => candidato.ID_lista == listaId);

            // Crea la tabella dei candidati
            const html = `
                <td colspan="2">
                    <table class="tabella-sindaco">
                        ${candidatiLista.map(candidato => `
                            <tr>
                                <td class="is-size-6">
                                    <input type="checkbox" class="candidato-checkbox" 
                                        value="${candidato.ID}" 
                                        data-lista-id="${listaId}">
                                </td>
                                <td class="subtitle">
                                    ${candidato.nome} ${candidato.cognome} 
                                    <small class="is-size-6">(${candidato.numCandidato}: ${candidato.ruoloCandidato})</small>
                                </td>
                            </tr>
                        `).join('')}
                    </table>
                </td>
            `;

            rigaCandidati.innerHTML = html;
        });
    });

    // Aggiungi event listener per i bottoni "Vota" (VOTAZIONE) -------------------------------------------------------------------------
    
    
    if(!sessione.voto){
        sindaci.data.forEach(sindaco => {
            const button = document.getElementById(`vota-btn-${sindaco.ID}`);
            
            button.addEventListener('click', async function() {
                
                const selezioneLista = document.getElementById(`selezioneLista-${sindaco.ID}`);
                const listaId = parseInt(selezioneLista.value);

                const candidatiSindaco = document.getElementById(`candidatiSindaco-${sindaco.ID}`);
                const candidatiSelezionati = 
                Array.from( candidatiSindaco.querySelectorAll('.candidato-checkbox:checked')
                ).map(cb => parseInt(cb.value));


                // Prepara l'oggetto voto
                const esitoVoto = {
                    ID_sindaco: parseInt(sindaco.ID),     
                    
                    ID_seggio: sessione.ID_seggio,
                    
                    CF: sessione.CF,

                    ID_lista: listaId,
                    ID_candidati: candidatiSelezionati
                };

                console.log("Dati del voto da inviare:", esitoVoto);

                try {
                    const fetchVotazione = await fetch('http://localhost/swbd/PHP/votazione.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(esitoVoto)
                    });
                    

                    const votazione = await fetchVotazione.json();
                    console.log(votazione);
                    
                    if (votazione.successo === 1) {
                        alert("Voto registrato con successo!");
                        location.reload();
                    } else {
                        alert("Errore durante la votazione: " + (votazione.message || ""));
                    }
                        
                } catch (error) {
                    //console.log("la response:", votazione.successo);
                    alert("Errore di connessione: " + error.message);
                }
            });
        });
    }
    
}
