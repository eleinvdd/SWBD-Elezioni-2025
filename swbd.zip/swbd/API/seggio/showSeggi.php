<?php
	
	require_once __DIR__ . '/../class/Seggi.php';

    $api = new Seggi();
    
    $response = $api->getRows(null);

    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);

?>