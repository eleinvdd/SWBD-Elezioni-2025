function validateRegistration() {
    var codice_fiscale = document.registrazione.codice_fiscale.value;
    var email = document.registrazione.email.value;
    var password = document.registrazione.password.value;
    
    //Espressione regolare del codice fiscale
    var cf_valid = /^[A-Za-z]{6}[0-9]{2}[A-Za-z][0-9]{2}[A-Za-z][0-9]{3}[A-Za-z]$/;

    //Espressione regolare dell'email
    var email_valid = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-]{2,})+.)+([a-zA-Z0-9]{2,})+$/;
    
    if (codice_fiscale.length != 16 || !cf_valid.test(codice_fiscale) || (codice_fiscale == "") || (codice_fiscale == "undefined") ) 
    {
        alert("Devi inserire un codice fiscale valido");
        document.registrazione.codice_fiscale.focus();
        return false;
    }

    if (!email_valid.test(email) || (email == "") || (email == "undefined")) 
    {
        alert("Devi inserire un indirizzo mail corretto");
        document.registrazione.email.focus();
        return false;
    }

    if (password.length < 6 || (password == "") || (password == "undefined") ) 
    {
        alert("Scegli una password, minimo 6 caratteri");
        document.registrazione.password.focus();
        return false;
    }
    document.registrazione.submit();
}


function alreadyRegistered(){
    var response;
}