-- PROCEDURE PER ACCEDERE DAL CANDIDATO AL SINDACO -------------------
DELIMITER $$

CREATE PROCEDURE findSindacoFromCandidato (
    IN candidato_id INT,
    OUT sindaco_id INT)
BEGIN
    SELECT Sindaci.ID
    INTO sindaco_id
    FROM 
      Candidati 
      INNER JOIN Liste
        ON Candidati.ID_lista = Liste.ID
      INNER JOIN Sindaci
        ON Liste.ID_sindaco = Sindaci.ID
    WHERE Candidati.ID = candidato_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PROCEDURE PER ACCEDERE DAL CANDIDATO ALLA LISTA -------------------
DELIMITER $$

CREATE PROCEDURE findListaFromCandidato (
    IN candidato_id INT,
    OUT lista_id INT)
BEGIN
    SELECT liste.ID
    INTO lista_id
    FROM 
      Candidati 
      INNER JOIN Liste
        ON Candidati.ID_lista = Liste.ID
    WHERE Candidati.ID = candidato_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PROCEDURE PER ACCEDERE DALLA LISTA AL SINDACO -------------------
DELIMITER $$

CREATE PROCEDURE findSindacoFromLista (
    IN lista_id INT,
    OUT sindaco_id INT
)
BEGIN
    SELECT Sindaci.ID
    INTO sindaco_id
    FROM Sindaci
    INNER JOIN Liste ON Liste.ID_sindaco = Sindaci.ID
    WHERE Liste.ID = lista_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PER INCREMENTARE LA PREFERENZA "candidato" ------------------------
DELIMITER $$

CREATE PROCEDURE IncrementaPreferenzeCandidato (IN candidato_id INT)
BEGIN
    UPDATE Candidati
    SET numPreferenze = numPreferenze + 1
    WHERE ID = candidato_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PER INCREMENTARE LA PREFERENZA "lista" ------------------------

DELIMITER $$

CREATE PROCEDURE IncrementaPreferenzeLista (IN lista_id INT)
BEGIN
    UPDATE Liste
    SET numPreferenze = numPreferenze + 1
    WHERE ID = lista_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PER INCREMENTARE LA PREFERENZA "sindaco" ------------------------
DELIMITER $$

CREATE PROCEDURE IncrementaPreferenzeSindaco (IN sindaco_id INT)
BEGIN
    UPDATE Sindaci
    SET numPreferenze = numPreferenze + 1
    WHERE ID = sindaco_id;
END$$

DELIMITER ;
-- -------------------------------------------------------------------

-- PROCEDURE PER ASSOCIARE "Utente" alla persona -------------------
DELIMITER $$

CREATE PROCEDURE associaUtente (
    IN user_ID INT,
    IN user_type VARCHAR(20),
    IN codice_fiscale VARCHAR(16)
)
BEGIN
    DECLARE rows_updated INT DEFAULT 0;

    IF user_type = 'Cittadino' THEN
        UPDATE Cittadini
        SET ID_utente = user_ID
        WHERE CF = codice_fiscale;
        SET rows_updated = ROW_COUNT();

    ELSEIF user_type = 'Addetto' THEN
        UPDATE Addetti
        SET ID_utente = user_ID
        WHERE CF = codice_fiscale;
        SET rows_updated = ROW_COUNT();

    ELSEIF user_type = 'Candidato' THEN
        UPDATE Candidati
        SET ID_utente = user_ID
        WHERE CF = codice_fiscale;
        SET rows_updated = ROW_COUNT();

    ELSEIF user_type = 'Sindaco' THEN
        UPDATE Sindaci
        SET ID_utente = user_ID
        WHERE CF = codice_fiscale;
        SET rows_updated = ROW_COUNT();

    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'userType non valido';
    END IF;

    IF rows_updated = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Nessun record aggiornato: CF non trovato';
    END IF;
END$$

DELIMITER ;
-- -------------------------------------------------------------------