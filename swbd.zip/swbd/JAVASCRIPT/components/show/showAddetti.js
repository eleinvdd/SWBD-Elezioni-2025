// Genera le tabelle al caricamento della pagina
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Fetch dei dati
        const fetchAddetti = await fetch('http://localhost/swbd/API/addetto/showAddetti.php');
        const addetti = await fetchAddetti.json();
        
        
        if(addetti.successo === 1){
            renderAddetti(addetti.data);
        }
        else{
            if(addetti.successo === 0) {
                console.error('Errore:', addetti.messaggio);
                showError();
            }
        }
    } catch (error) {
        console.error('Errore fetch:', error);
        showError();
    }
});

async function renderAddetti(addetti) {
    console.log("Risposta addetti:", addetti);

    const container = document.getElementById('addetti-container');
    container.innerHTML = ''; // Pulisce prima

    // Creiamo il contenuto HTML per ogni candidato
    addetti.forEach(addetto => {
        
        const dataNascita = new Date(addetto.data_nascita);
        const dataFormattata = dataNascita.toLocaleDateString('it-IT');
        
        //CALCOLO ETA' --------------------------------------------------------------------------------
        const oggi = new Date();
        let eta = oggi.getFullYear() - dataNascita.getFullYear();
        const mese = oggi.getMonth() - dataNascita.getMonth();
        if (mese < 0 || (mese === 0 && oggi.getDate() < dataNascita.getDate())) {
            eta--;
        }
        

        const addettoHTML = `
        <div class="box">
            <div class="columns">
                <div class="column">
                    <h2 class="title is-3">${addetto.nome} ${addetto.cognome}</h2>
                    <h3 class="subtitle is-5">${addetto.ruolo}</h3>
                    <hr class="my-5"></hr>
                    <div class="content">
                        <p><strong class="is-size-5">Data di nascita:</strong> ${dataFormattata} (${eta} anni)</p>
                        <p><strong class="is-size-5">Codice Fiscale:</strong> ${addetto.CF}</p>
                        
                    </div>
                </div>
            </div>
        </div>
        `;

        container.insertAdjacentHTML('beforeend', addettoHTML);
    });
}

function showError() {
    const container = document.getElementById('liste-container');
    container.innerHTML = `
        <div class="notification is-danger">
            Errore nel caricamento degli addetti. Riprova più tardi.
        </div>
    `;
}