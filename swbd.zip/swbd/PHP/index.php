<?php
    //header("Access-Control-Allow-Origin: *");
    
    //CONNESSIONE AL DATABASE ----------------------------------------------------------------------------------
    require_once __DIR__ . '/config/connection.php';
    
    //CORRETTEZZA DEI DATI ----------------------------------------------------------------------------------
    require_once __DIR__ . '/config/checks.php';
    
    //GESTIONE LOGIN ----------------------------------------------------------------------------------
    //require_once __DIR__ . 'config/auth.php';
?>