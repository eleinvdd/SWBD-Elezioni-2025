<?php
	
	require_once __DIR__ . '/Rest.php';

	class Voti extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Voti"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertVoto($rowVoto) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(ID_seggio, ID_sindaco) 
					VALUES (?, ?)";
			
			$params = [
				$rowVoto["ID_seggio"],
				$rowVoto["ID_sindaco"],
			];
			
			$types = "ii"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateVoto($rowVoto){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					ID_seggio = ?, 
					ID_sindaco = ? 
				WHERE ID = ?";
			
			$params = [
				$rowVoto["ID_seggio"],
				$rowVoto["ID_sindaco"],
				$rowVoto["ID_voto"],
			];
			
			$types = "iii"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

	}


?>