<?php
	
	require_once __DIR__ . '/Rest.php';

	class Utenti extends Rest{

		//COSTRUTTORE -------------------------------------------------------------------------
		public function __construct() {
			$this->tabella = "Utenti"; // Imposta la tabella
			parent::__construct(); // Richiama il costruttore del genitore
		}
		//--------- -------------------------------------------------------------------------

		//INSERT -------------------------------------------------------------------------
		public function insertUtente($rowUtente) {
			
			$query = "INSERT INTO ".$this->tabella." 
					(email, pass, CF, userType) 
					VALUES (?, ?, ?, ?)";
			
			$params = [
				$rowUtente["email"],
				$rowUtente["pass"],
				$rowUtente["CF"],
				$rowUtente["userType"]
			];
			
			$types = "sssi"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			return $response;
		}
		//--------- -------------------------------------------------------------------------

		//UPDATE -------------------------------------------------------------------------
		public function updateUtente($rowUtente){ 	

			$query= "UPDATE ".$this->tabella." 
				SET 
					email = ?, 
					pass = ?, 
					CF = ?, 
					userType = ? 
				WHERE ID = ?";
			
			$params = [
				$rowUtente["email"],
				$rowUtente["pass"],
				$rowUtente["CF"],
				$rowUtente["userType"],
                $rowUtente["ID_utente"],
			];

			$types = "ssssi"; // s=stringa, i=intero	

			$response = $this->iudQuery($query, $params, $types);
			return $response;

		}
		//--------- -------------------------------------------------------------------------

		public function emailExists($email){ 	

			$query = "SELECT email FROM ".$this->tabella." WHERE email = ?";
			
			$params = [
				$rowUtente["email"] = $email,
			];
			
			$types = "s"; // s=stringa, i=intero
			
			$response = $this->iudQuery($query, $params, $types);
			
			//if ()

		}
        

	}

?>