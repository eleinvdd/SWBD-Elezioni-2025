<?php
	require_once __DIR__ . '/../class/Utenti.php';

	header('Content-Type: application/json');

	$api = new Utenti();
	$input = json_decode(file_get_contents("php://input"), true);

	$rowUtente["ID_utente"] = $input['ID_utente'];
	$rowUtente["email"] = $input['email'];
	$rowUtente["pass"] = $input['pass'];
	$rowUtente["userType"] = $input['userType'];
	$rowUtente["CF"] = $input['CF'];

	$response = $api->updateUtente($rowUtente);

    echo json_encode($response, JSON_PRETTY_PRINT);
?>