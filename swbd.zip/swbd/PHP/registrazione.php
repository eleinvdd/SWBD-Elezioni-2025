<?php 
    require_once __DIR__ . '/index.php';

    //registra solo cittadini
    $userType = "Cittadino";

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        die("Metodo non consentito");
    }
    
    if (!empty($_POST['codice_fiscale']) && !empty($_POST['email']) && !empty($_POST['password'])) {

        //estrazione dei dati della form ---------------------------------------------------------------------------------------------
        $codice_fiscale = $conn->real_escape_string($_POST['codice_fiscale']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];

        //----------------------------------------------------------------------------------------------------------------------------

        //prevenzione sui dati -------------------------------------------------------------------------------------------------------
        $email = strtolower($email);
        $email = stripslashes($email);
        $options = array("cost"=>12);
        $hashPassword = password_hash($password, PASSWORD_BCRYPT, $options);

        //----------------------------------------------------------------------------------------------------------------------------

        //invio dei dati al server ---------------------------------------------------------------------------------------------------
        $stmt = $conn->prepare("INSERT INTO Utenti (CF, userType, email, pass) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $codice_fiscale, $userType, $email, $hashPassword);
        

        //SE LA REGISTRAZIONE VIENE EFFETTUATA CON SUCCESSO ESEGUO ANCHE IL LOGIN
        if($stmt->execute()){
            
            // ------------------------------------------------------------------------------------------------
            session_start();
            $_SESSION['ID_user'] = $stmt->insert_id;
            $_SESSION['email'] = $email;
            $_SESSION['userType'] = $userType;
            $_SESSION['CF'] = $codice_fiscale;
            $_SESSION['voto'] = false; // Impostato a false per nuova registrazione
            $_SESSION['ID_seggio'] = 1;// Impostato inizialmente a 1, sarà poi l'utente a cambiarlo dal profilo
            // --------------------------------------------------------------------------------------------------------------
            //entra in homeCittadino in quanto userType è fissato a "Cittadino"
            if($_SESSION['userType'] == "Admin"){
                header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/admin.php");
                exit();
            }
            else{
                header("Location: http://" . $_SERVER['HTTP_HOST'] . "/swbd/HTML/home". $_SESSION['userType'] .".php");
                exit();
            }
            // -----------------------------------------------------------------------------------------------------------
        }
        else{
            header('Content-Type: application/json');
            echo json_encode(["error" => $stmt->error]);
        }
        
        $stmt->close();
    }

?>
